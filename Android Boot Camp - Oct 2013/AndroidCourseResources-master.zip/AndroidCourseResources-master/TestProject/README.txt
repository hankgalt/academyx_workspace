This is a project that demonstrates how to do multitouch.

-- Bill
